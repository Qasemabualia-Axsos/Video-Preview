console.log("page loaded...");


function over(videoElem) {
  videoElem.play();
}

function out(videoElem) {
  videoElem.pause();
}

  